package com.jhutch50.resumesandwichapplication;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ResumeSandwichApplication {

	public static void main(String[] args) {
		SpringApplication.run(ResumeSandwichApplication.class, args);
	}

}
